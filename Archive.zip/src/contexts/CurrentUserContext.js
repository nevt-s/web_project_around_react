import React from "react";

export const currentUserContext = React.createContext();